# Figure Inventory

All current manuscript and graphical-abstract figures are kept in this directory.
The repository root of `paper/` should not contain standalone figure files.

## Current figures

Each main manuscript figure is generated from its `.puml` source in four submission-facing formats:

- `.pdf`: vector file referenced by the manuscript LaTeX source
- `.eps`: vector fallback for publisher artwork upload
- `.svg`: vector source/check file for visual inspection
- `.png`: high-resolution raster preview

Current PlantUML sources for manuscript figures:

- `figure_1_standards_traceability_architecture.puml`
- `figure_2a_conceptual_uml.puml`
- `figure_2b_metric_uml.puml`
- `figure_3_telemetry_to_reporting_pipeline.puml`

The graphical abstract is generated from `graphical_abstract.py` as an exact-ratio vector PDF/SVG/EPS plus a high-resolution PNG preview.

The manuscript references the main figures as PDF vector files. The graphical abstract is supplied as both `graphical_abstract.pdf` and `graphical_abstract.png`; the PNG preview is `3000 x 1200` pixels, exceeding the Elsevier minimum of `1328 x 531` pixels while preserving a 2.5:1 aspect ratio.

## Regeneration

From the repository root:

```powershell
Get-ChildItem paper\figures -Filter 'figure_*.puml' | ForEach-Object {
  java -jar tools\plantuml.jar --png $_.FullName
  java -jar tools\plantuml.jar --svg $_.FullName
  java -jar tools\plantuml.jar --eps $_.FullName
  $eps = [System.IO.Path]::ChangeExtension($_.FullName, '.eps')
  $pdf = [System.IO.Path]::ChangeExtension($_.FullName, '.pdf')
  epstopdf $eps --outfile=$pdf
}
python paper\figures\graphical_abstract.py
```
