from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch


OUT = Path(__file__).resolve().parent

COLORS = {
    "ink": "#263238",
    "arrow": "#37474F",
    "standard": "#E3F2FD",
    "model": "#E8F5E9",
    "evidence": "#F3E5F5",
    "output": "#FFF3E0",
    "band": "#ECEFF1",
}


def add_stage(ax, x, y, w, h, face, title, lines):
    box = FancyBboxPatch(
        (x, y),
        w,
        h,
        boxstyle="round,pad=0.018,rounding_size=0.035",
        linewidth=1.15,
        edgecolor=COLORS["ink"],
        facecolor=face,
    )
    ax.add_patch(box)
    ax.text(
        x + w / 2,
        y + h - 0.18,
        title,
        ha="center",
        va="top",
        fontsize=12.4,
        fontweight="bold",
        linespacing=1.05,
        color=COLORS["ink"],
    )
    ax.text(
        x + w / 2,
        y + h / 2 - 0.08,
        "\n".join(lines),
        ha="center",
        va="center",
        fontsize=10.5,
        linespacing=1.22,
        color=COLORS["ink"],
    )


def add_arrow(ax, x1, y1, x2, y2):
    ax.add_patch(
        FancyArrowPatch(
            (x1, y1),
            (x2, y2),
            arrowstyle="-|>",
            mutation_scale=18,
            linewidth=1.6,
            color=COLORS["arrow"],
            shrinkA=5,
            shrinkB=5,
        )
    )


def main() -> None:
    fig = plt.figure(figsize=(10, 4), dpi=300)
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4)
    ax.axis("off")
    fig.patch.set_facecolor("white")

    ax.text(
        0.35,
        3.62,
        "Standards-traceable security-risk evidence flow",
        ha="left",
        va="center",
        fontsize=18,
        fontweight="bold",
        color=COLORS["ink"],
    )

    y, w, h = 1.35, 2.02, 1.62
    xs = [0.35, 2.80, 5.25, 7.63]
    stages = [
        (
            COLORS["standard"],
            "Standards scope",
            ["ISO/IEC 27001:2022", "NIST CSF 2.0", "official references"],
        ),
        (
            COLORS["model"],
            "Traceability model",
            ["UML/XMI classes", "GQM metric links", "provenance fields"],
        ),
        (
            COLORS["evidence"],
            "Public evidence",
            ["CIC IoT 2023 flows", "flow-only IDS path", "calibrated EP"],
        ),
        (
            COLORS["output"],
            "Governance\noutputs",
            ["residual-risk summaries", "TCO frontiers", "CSV/LaTeX exports"],
        ),
    ]

    for x, (face, title, lines) in zip(xs, stages):
        add_stage(ax, x, y, w, h, face, title, lines)

    for left, right in zip(xs[:-1], xs[1:]):
        add_arrow(ax, left + w + 0.04, y + h / 2, right - 0.04, y + h / 2)

    band = FancyBboxPatch(
        (0.35, 0.35),
        9.3,
        0.55,
        boxstyle="round,pad=0.018,rounding_size=0.025",
        linewidth=1.0,
        edgecolor=COLORS["ink"],
        facecolor=COLORS["band"],
    )
    ax.add_patch(band)
    ax.text(
        5,
        0.625,
        "Public artifact: executable code, standards mappings, UML/XMI assets,\nvalidator outputs, and reproducibility instructions.",
        ha="center",
        va="center",
        fontsize=10.3,
        linespacing=1.2,
        color=COLORS["ink"],
    )

    for ext in ("pdf", "svg", "eps", "png"):
        fig.savefig(OUT / f"graphical_abstract.{ext}", dpi=300, facecolor="white")
    plt.close(fig)


if __name__ == "__main__":
    main()
