"""Portfolio optimization utilities."""

