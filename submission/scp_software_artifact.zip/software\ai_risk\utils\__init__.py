"""Common utilities."""

